import React, { useState, useEffect } from 'react';
import { Github, Mail, ExternalLink, Code2, Terminal, Database, Globe, Linkedin, BookOpen, Award, Users } from 'lucide-react';

function App() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-blue-900 to-violet-900 text-white">
      {/* Hero Section */}
      <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[length:32px_32px]"></div>
        <div className="relative z-10 text-center space-y-8 px-4">
          <div className="w-48 h-48 mx-auto mb-8 rounded-full overflow-hidden ring-4 ring-purple-500/30">
            <img
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80"
              alt="Harika Mallu"
              className="w-full h-full object-cover"
            />
          </div>
          <h1 className="text-7xl sm:text-9xl font-bold tracking-tighter">
            Harika Mallu
          </h1>
          <p className="text-2xl sm:text-3xl text-blue-200 font-light">CSIT Student & Aspiring Developer</p>
          <p className="text-xl text-blue-200">
            A dedicated second-year CSIT student passionate about technology and web development
          </p>
          <div className="flex justify-center gap-6">
            <a href="https://github.com/2300090030" className="p-4 bg-white/10 rounded-full hover:bg-white/20 transition-colors">
              <Github size={24} />
            </a>
            <a href="https://linkedin.com/in/harika-mallu-b0491531a" className="p-4 bg-white/10 rounded-full hover:bg-white/20 transition-colors">
              <Linkedin size={24} />
            </a>
            <a href="mailto:2300099003csit@gmail.com" className="p-4 bg-white/10 rounded-full hover:bg-white/20 transition-colors">
              <Mail size={24} />
            </a>
          </div>
          <div className="text-blue-200">
            <p>+91 8985329312 | 2300099003csit@gmail.com</p>
          </div>
        </div>
      </div>

      {/* Education */}
      <section className="py-32 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-16 text-center">Education</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white/5 p-8 rounded-2xl backdrop-blur-sm">
              <h3 className="text-2xl font-bold mb-2">KL University</h3>
              <p className="text-blue-200">Computer Science and Information Technology</p>
              <p className="text-blue-200">CGPA: 9.4</p>
              <p className="text-blue-300">Sept 2023 - May 2027 | Guntur</p>
            </div>
            <div className="bg-white/5 p-8 rounded-2xl backdrop-blur-sm">
              <h3 className="text-2xl font-bold mb-2">Sri Srinivasa Junior College</h3>
              <p className="text-blue-200">Intermediate (MPC)</p>
              <p className="text-blue-200">CGPA: 9.38</p>
              <p className="text-blue-300">Sept 2021 - May 2023 | Kavali</p>
            </div>
          </div>
        </div>
      </section>

      {/* Projects */}
      <section className="py-32 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-16 text-center">Featured Project</h2>
          <div className="bg-white/5 rounded-2xl overflow-hidden backdrop-blur-sm">
            <div className="p-8">
              <h3 className="text-2xl font-bold mb-4">Online Grocery Store</h3>
              <p className="text-blue-200 mb-6">Nov 2024 - Present</p>
              <ul className="space-y-3 text-blue-200">
                <li>• Developed a responsive frontend using React and Bootstrap</li>
                <li>• Designed MySQL database for product and user management</li>
                <li>• Built Node.js backend API for authentication and cart management</li>
                <li>• Integrated secure payment processing and order tracking</li>
              </ul>
              <div className="flex flex-wrap gap-2 mt-6">
                {['React', 'Bootstrap', 'JavaScript', 'MySQL', 'Node.js'].map((tech) => (
                  <span key={tech} className="px-3 py-1 bg-white/10 rounded-full text-sm">
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills */}
      <section className="py-32 px-4 bg-white/5">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-16">Technical Skills</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <Code2 size={40} className="mx-auto text-blue-300" />
              <h3 className="text-xl font-semibold">Languages</h3>
              <ul className="text-blue-200">
                <li>C</li>
                <li>Python</li>
                <li>Java (Basics)</li>
              </ul>
            </div>
            <div className="space-y-4">
              <Globe size={40} className="mx-auto text-blue-300" />
              <h3 className="text-xl font-semibold">Web Development</h3>
              <ul className="text-blue-200">
                <li>HTML, CSS</li>
                <li>JavaScript</li>
                <li>React.js, Node.js</li>
              </ul>
            </div>
            <div className="space-y-4">
              <Database size={40} className="mx-auto text-blue-300" />
              <h3 className="text-xl font-semibold">Databases</h3>
              <ul className="text-blue-200">
                <li>SQL</li>
                <li>PostgreSQL</li>
                <li>MongoDB</li>
              </ul>
            </div>
            <div className="space-y-4">
              <Terminal size={40} className="mx-auto text-blue-300" />
              <h3 className="text-xl font-semibold">Tools</h3>
              <ul className="text-blue-200">
                <li>Eclipse</li>
                <li>VS Code</li>
                <li>Dev C++</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Certifications & Achievements */}
      <section className="py-32 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-16 text-center">Certifications & Achievements</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white/5 p-8 rounded-2xl backdrop-blur-sm">
              <Award className="text-blue-300 mb-4" size={32} />
              <h3 className="text-2xl font-bold mb-2">Salesforce AI Associate</h3>
              <p className="text-blue-200">Credential ID: 5104607</p>
              <p className="text-blue-200">Demonstrated expertise in AI concepts and applications</p>
            </div>
            <div className="bg-white/5 p-8 rounded-2xl backdrop-blur-sm">
              <Users className="text-blue-300 mb-4" size={32} />
              <h3 className="text-2xl font-bold mb-2">National Cadet Corps</h3>
              <p className="text-blue-200">Corporal | Jul 2023 - Mar 2026</p>
              <p className="text-blue-200">Led a team of 52 cadets in drills and service activities</p>
            </div>
          </div>
        </div>
      </section>

      {/* Coding Platforms */}
      <section className="py-32 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-8">Coding Platforms</h2>
          <div className="flex justify-center gap-8">
            <a href="https://leetcode.com/u/klu2300090030" className="text-blue-200 hover:text-blue-100">LeetCode</a>
            <a href="https://www.codechef.com/users/kluv2300090030" className="text-blue-200 hover:text-blue-100">CodeChef</a>
            <a href="https://www.hackerrank.com/profile/h2300090030" className="text-blue-200 hover:text-blue-100">HackerRank</a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 text-center text-blue-200">
        <p>© {new Date().getFullYear()} Harika Mallu. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;